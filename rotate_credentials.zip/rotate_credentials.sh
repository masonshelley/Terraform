#!/bin/bash

# Function to generate a random password
generate_password() {
    # Use openssl to generate a random string
    password=$(openssl rand -base64 12)
    echo "$password"
}

# Function to rotate user credentials
rotate_credentials() {
    local user_name=$1
    local new_password=$2
    
    # Update the user's password
    echo "$user_name:$new_password" | chpasswd
    
    echo "Password rotated for user: $user_name"
}

# Main function
main() {
    local user_name=$1
    local new_password=$(generate_password)
    
    rotate_credentials "$user_name" "$new_password"
}

# Call main function with the username as an argument
main "$@"
